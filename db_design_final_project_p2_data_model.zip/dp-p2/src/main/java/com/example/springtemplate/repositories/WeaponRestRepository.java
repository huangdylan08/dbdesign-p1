package com.example.springtemplate.repositories;

import com.example.springtemplate.models.Weapon;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface WeaponRestRepository
        extends CrudRepository<Weapon, Integer> {
    @Query(value = "SELECT * FROM weapons",
            nativeQuery = true)
    public List<Weapon> findAllWeapons();
    @Query(value = "SELECT * FROM weapons WHERE id=:weaponId",
            nativeQuery = true)
    public Weapon findWeaponById(@Param("weaponId") Integer id);
}
