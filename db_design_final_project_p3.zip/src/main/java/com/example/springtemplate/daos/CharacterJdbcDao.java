package com.example.springtemplate.daos;

import com.example.springtemplate.models.Character;
import com.example.springtemplate.models.WeaponType;
import com.example.springtemplate.models.Element;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CharacterJdbcDao {
    static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String HOST = "localhost:3306";
    static final String SCHEMA = "YOUR_SCHEMA";
    static final String CONFIG = "serverTimezone=UTC";
    static final String URL =
            "jdbc:mysql://"+HOST+"/"+SCHEMA+"?"+CONFIG;
    static final String USERNAME = "YOUR_USERNAME";
    static final String PASSWORD = "YOUR_PASSWORD";
    
    static Connection connection = null;
    static PreparedStatement statement = null;
    String CREATE_CHARACTER = "INSERT INTO characters VALUES (null, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    String FIND_ALL_CHARACTERS = "SELECT * FROM characters";
    String FIND_CHARACTER_BY_ID = "SELECT * FROM characters WHERE id=?";
    String DELETE_CHARACTER = "DELETE FROM characters WHERE id=?";
    String UPDATE_CHARACTER = "UPDATE characters SET name=?, level=?, rarity=?, attack=?, health=?, weapon_type=?, element=?, user_id=?, weapon_id=? WHERE id=?";
    
    private Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName(DRIVER);
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
    
    private void closeConnection(Connection connection) throws SQLException {
        connection.close();
    }
    
    public Character findCharacterById(Integer id) throws SQLException, ClassNotFoundException {
        UserJdbcDao userJdbcDao = new UserJdbcDao();
        Character character = null;
        connection = getConnection();

        statement = connection.prepareStatement(FIND_CHARACTER_BY_ID);
        statement.setInt(1, id);
        ResultSet resultSet = statement.executeQuery();
        if(resultSet.next()) {
            character = new Character(
                    resultSet.getString("name"),
                    resultSet.getInt("level"),
                    resultSet.getInt("rarity"),
                    resultSet.getInt("attack"),
                    resultSet.getInt("health"),
                    resultSet.getString("weapon_type"),
                    resultSet.getString("element"),
                    resultSet.getString("user_id"),
                    resultSet.getString("weapon_id")
            );
        }

        closeConnection(connection);
        return character;
    }
    
    public Integer deleteCharacter(Integer characterId) throws SQLException, ClassNotFoundException {
        Integer rowsDeleted = 0;
        connection = getConnection();

        statement = connection.prepareStatement(DELETE_CHARACTER);
        statement.setInt(1, characterId);
        rowsDeleted = statement.executeUpdate();

        closeConnection(connection);
        return rowsDeleted;
    }
    
    public Integer updateCharacter(Integer characterId, Character newCharacter) throws SQLException, ClassNotFoundException {
        Integer rowsUpdated = 0;
        connection = getConnection();

        statement = connection.prepareStatement(UPDATE_CHARACTER);
        statement.setString(1, newCharacter.getName());
        statement.setInt(2, newCharacter.getLevel());
        statement.setInt(3, newCharacter.getRarity());
        statement.setInt(4, newCharacter.getAttack());
        statement.setInt(5, newCharacter.getHealth());
        statement.setString(6, newCharacter.getWeaponType().toString());
        statement.setString(7, newCharacter.getElement().toString());
        statement.setInt(8, newCharacter.getUser());
        statement.setInt(9, newCharacter.getWeapon());
        statement.setInt(10, characterId);
        rowsUpdated = statement.executeUpdate();

        closeConnection(connection);
        return rowsUpdated;
    }
    
    public List<Character> findAllCharacters() throws ClassNotFoundException, SQLException {
        UserJdbcDao userJdbcDao = new UserJdbcDao();
        List<Character> characters = new ArrayList<Character>();
        connection = getConnection();

        statement = connection.prepareStatement(FIND_ALL_CHARACTERS);
        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            Character character = new Character(
                    resultSet.getString("name"),
                    resultSet.getInt("level"),
                    resultSet.getInt("rarity"),
                    resultSet.getInt("attack"),
                    resultSet.getInt("health"),
                    resultSet.getString("weapon_type"),
                    resultSet.getString("element"),
                    resultSet.getString("user_id"),
                    resultSet.getString("weapon_id")
            );
            characters.add(character);
        }

        closeConnection(connection);
        return characters;
    }
    public Integer createCharacter(Character character)
            throws ClassNotFoundException, SQLException {
        Integer rowsUpdated = 0;
        connection = getConnection();

        statement = connection.prepareStatement(CREATE_CHARACTER);
        statement.setString(1, character.getName());
        statement.setInt(2, character.getLevel());
        statement.setInt(3, character.getRarity());
        statement.setInt(4, character.getAttack());
        statement.setInt(5, character.getHealth());
        statement.setString(6, character.getWeaponType().toString());
        statement.setString(7, character.getElement().toString());
        statement.setInt(8, character.getUser());
        statement.setInt(9, character.getWeapon());
        rowsUpdated = statement.executeUpdate();

        closeConnection(connection);
        return rowsUpdated;
    }
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        CharacterJdbcDao dao = new CharacterJdbcDao();
    }
}
