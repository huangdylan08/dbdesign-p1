package com.example.springtemplate.daos;

import com.example.springtemplate.models.Character;
import com.example.springtemplate.repositories.CharacterRestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class CharacterRestOrmDao {
    @Autowired
    CharacterRestRepository characterRepository;

    @PostMapping("/api/characters")
    public Character createCharacter(@RequestBody Character character) {
        return characterRepository.save(character);
    }
    
    @GetMapping("/api/characters")
    public List<Character> findAllCharacters() {
        return characterRepository.findAllCharacters();
    }
    
    @GetMapping("/api/characters/{characterId}")
    public Character findCharacterById(
            @PathVariable("characterId") Integer id) {
        return characterRepository.findCharacterById(id);
    }
    
    @PutMapping("/api/characters/{characterId}")
    public Character updateCharacter(
            @PathVariable("characterId") Integer id,
            @RequestBody Character characterUpdates) {
        Character character = characterRepository.findCharacterById(id);
        character.setName(characterUpdates.getName());
        character.setLevel(characterUpdates.getLevel());
        character.setRarity(characterUpdates.getRarity());
        character.setAttack(characterUpdates.getAttack());
        character.setHealth(characterUpdates.getHealth());
        character.setWeaponType(characterUpdates.getWeaponType());
        character.setElement(characterUpdates.getElement());
        character.setUser(characterUpdates.getUser());
        character.setWeapon(characterUpdates.getWeapon());
        return characterRepository.save(character);
    }
    
    @DeleteMapping("/api/characters/{characterId}")
    public void deleteCharacter(
            @PathVariable("characterId") Integer id) {
        characterRepository.deleteById(id);
    }
}