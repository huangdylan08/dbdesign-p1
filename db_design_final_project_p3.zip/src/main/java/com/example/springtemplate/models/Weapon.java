package com.example.springtemplate.models;

import com.fasterxml.jackson.annotation.*;

import javax.persistence.*;

@Entity
@Table(name="weapons")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Weapon {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private String weaponType;
    private Integer level;
    private Integer refinementLevel;
    private Integer rarity;
    private Integer baseAttack;
    private String abilityName;
    private String abilityDescription;
    @OneToOne
    private Character character;

    public Weapon() {

    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getWeaponType() { return weaponType; }
    public void setWeaponType(String weaponType) { this.weaponType = weaponType; }
    public Integer getLevel() { return level; }
    public void setLevel(Integer level) { this.level = level; }
    public Integer getRefinementLevel() { return refinementLevel; }
    public void setRefinementLevel(Integer refinementLevel) { this.refinementLevel = refinementLevel; }
    public Integer getRarity() { return rarity; }
    public void setRarity(Integer rarity) { this.rarity = rarity; }
    public Integer getBaseAttack() { return baseAttack; }
    public void setBaseAttack(Integer baseAttack) { this.baseAttack = baseAttack; }
    public String getAbilityName() { return abilityName; }
    public void setAbilityName(String abilityName) { this.abilityName = abilityName; }
    public String getAbilityDescription() { return abilityDescription; }
    public void setAbilityDescription(String abilityDescription) { this.abilityDescription = abilityDescription; }
    public Character getCharacter() { return character; }
    public void setCharacter(Character character) { this.character = character; }

    public Weapon(String name, String weaponType, Integer level, Integer refinementLevel, Integer rarity, Integer baseAttack, String abilityName, String abilityDescription, Character character) {
        this.name = name;
        this.weaponType = weaponType;
        this.level = level;
        this.refinementLevel = refinementLevel;
        this.rarity = rarity;
        this.baseAttack = baseAttack;
        this.abilityName = abilityName;
        this.abilityDescription = abilityDescription;
        this.character = character;
    }
}
