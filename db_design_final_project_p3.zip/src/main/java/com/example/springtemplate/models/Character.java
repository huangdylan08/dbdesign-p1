package com.example.springtemplate.models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name="characters")
public class Character {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private Integer level;
    private Integer rarity;
    private Integer attack;
    private Integer health;
    private String weaponType;
    private String element;

    @ManyToOne
    @JsonIgnore
    private Integer user;

    @OneToOne
    @JsonIgnore
    private Integer weapon;

    public Character() {

    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Integer getLevel() { return level; }
    public void setLevel(Integer level) { this.level = level; }
    public Integer getRarity() { return rarity; }
    public void setRarity(Integer rarity) { this.rarity = rarity; }
    public Integer getAttack() { return attack; }
    public void setAttack(Integer attack) { this.attack = attack; }
    public Integer getHealth() { return health; }
    public void setHealth(Integer health) { this.health = health; }
    public String getWeaponType() { return weaponType; }
    public void setWeaponType(String weaponType) { this.weaponType = weaponType; }
    public String getElement() { return element; }
    public void setElement(String element) { this.element = element; }
    public Integer getUser() { return user; }
    public void setUser(Integer user) { this.user = user; }
    public Integer getWeapon() { return weapon; }
    public void setWeapon(Integer weapon) { this.weapon = weapon; }

    public Character(String name, Integer level, Integer rarity, Integer attack, Integer health, String weaponType, String element, Integer user, Integer weapon) {
        this.name = name;
        this.level = level;
        this.rarity = rarity;
        this.attack = attack;
        this.health = health;
        this.weaponType = weaponType;
        this.element = element;
        this.user = user;
        this.weapon = weapon;
    }

    public Character(String name, Integer level, Integer rarity, Integer attack, Integer health, String weaponType, String element, String user, String weapon) {
        this.name = name;
        this.level = level;
        this.rarity = rarity;
        this.attack = attack;
        this.health = health;
        this.weaponType = weaponType;
        this.element = element;
        this.user = Integer.valueOf(user);
        this.weapon = Integer.valueOf(weapon);
    }
}
