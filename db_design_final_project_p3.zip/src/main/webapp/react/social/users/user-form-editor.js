import userService from "./user-service"
const {useState, useEffect} = React
const {Link, useParams, useHistory} = window.ReactRouterDOM;
const UserFormEditor = () => {
    const {id} = useParams()
    const [user, setUser] = useState({})
    const [characters, setCharacters] = useState([])
    useEffect(() => {
        if (id !== "new") {
            findUserById(id);
            findAllCharacters();
        }
    }, []);
    const findUserById = (id) =>
        userService.findUserById(id)
            .then(user => setUser(user))
    const deleteUser = (id) =>
        userService.deleteUser(id)
            .then(() => history.back())
    const createUser = (user) =>
        userService.createUser(user)
            .then(() => history.back())
    const updateUser = (id, newUser) =>
        userService.updateUser(id, newUser)
            .then(() => history.back())

    const findAllCharacters = () =>
        userService.findAllCharacters()
            .then(characters => setCharacters(characters))

    return (
        <div>
            <h2>User Editor</h2>
            <label>Id</label>
            <input value={user.id}/><br/>
            <label>First Name</label>
            <input
                onChange={(e) =>
                    setUser(user =>
                        ({...user, firstName: e.target.value}))}
                value={user.firstName}/><br/>
            <label>Last Name</label>
            <input
                onChange={(e) =>
                    setUser(user =>
                        ({...user, lastName: e.target.value}))}
                value={user.lastName}/><br/>
            <label>Username</label>
            <input
                onChange={(e) =>
                    setUser(user =>
                        ({...user, username: e.target.value}))}
                value={user.username}/><br/>
            <label>Password</label>
            <input
                onChange={(e) =>
                    setUser(user =>
                        ({...user, password: e.target.value}))}
                value={user.password}/><br/>

            <label>Owned Characters</label>

            <ul className="list-group">
                {
                    characters.filter(character => character.user.id == user.id || character.user == user.id)
                        .map(character =>
                            <li className = "list-group-item"
                                key={character.id}>
                                    <Link onClick={() => window.location.replace(`characters.html#/characters/${character.id}`)}>
                                        {character.name}
                                    </Link>
                                </li>)
                }
            </ul>

            <button className="btn btn-warning"
                onClick={() => {
                    history.back()}}>
                Cancel</button>
            <button className="btn btn-danger"
                onClick={() => deleteUser(user.id)}>
                Delete</button>
            <button className="btn btn-primary"
                onClick={() => updateUser(user.id, user)}>
                Save</button>
            <button className="btn btn-success"
                onClick={() => createUser(user)}>
                Create</button>
        </div>
    )
}

export default UserFormEditor