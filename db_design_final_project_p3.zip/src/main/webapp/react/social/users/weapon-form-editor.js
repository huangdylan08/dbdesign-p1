import weaponService from "./weapon-service"
const {useState, useEffect} = React
const {Link, useParams, useHistory} = window.ReactRouterDOM;
const WeaponFormEditor = () => {
    const {id} = useParams()
    const [weapon, setWeapon] = useState({})
    useEffect(() => {
        if (id !== "new") {
            findWeaponById(id)
        }
    }, []);
    const findWeaponById = (id) =>
        weaponService.findWeaponById(id)
            .then(weapon => setWeapon(weapon))
    const deleteWeapon = (id) =>
        weaponService.deleteWeapon(id)
            .then(() => history.back())
    const createWeapon = (weapon) =>
        weaponService.createWeapon(weapon)
            .then(() => history.back())
    const updateWeapon = (id, newWeapon) =>
        weaponService.updateWeapon(id, newWeapon)
            .then(() => history.back())
    return (
        <div>
            <h2>Weapon Editor</h2>
            <label>Id</label>
            <input value={weapon.id}/><br/>
            <label>Name</label>
            <input
                onChange={(e) =>
                    setWeapon(weapon =>
                        ({...weapon, name: e.target.value}))}
                value={weapon.name}/>
            <label>Weapon Type</label>
            <input
                onChange={(e) =>
                    setWeapon(weapon =>
                        ({...weapon, weaponType: e.target.value}))}
                value={weapon.weaponType}/>
            <label>Level</label>
            <input
                onChange={(e) =>
                    setWeapon(weapon =>
                                  ({...weapon, level: e.target.value}))}
                value={weapon.level}/>
            <label>Refinement Level</label>
            <input
                onChange={(e) =>
                    setWeapon(weapon =>
                                  ({...weapon, refinementLevel: e.target.value}))}
                value={weapon.refinementLevel}/>
            <label>Rarity</label>
            <input
                onChange={(e) =>
                    setWeapon(weapon =>
                                  ({...weapon, rarity: e.target.value}))}
                value={weapon.rarity}/>
            <label>Base Attack</label>
            <input
                onChange={(e) =>
                    setWeapon(weapon =>
                                  ({...weapon, baseAttack: e.target.value}))}
                value={weapon.baseAttack}/>
            <label>Ability name</label>
            <input
                onChange={(e) =>
                    setWeapon(weapon =>
                                  ({...weapon, abilityName: e.target.value}))}
                value={weapon.abilityName}/>
            <label>Ability Description</label>
            <input
                onChange={(e) =>
                    setWeapon(weapon =>
                                  ({...weapon, abilityDescription: e.target.value}))}
                value={weapon.abilityDescription}/>

            <Link onClick={() => window.location.replace(`characters.html#/characters/${weapon.character}`)}>
                Character
            </Link>
            <input
                onChange={(e) =>
                    setWeapon(weapon =>
                                    ({...weapon, character: e.target.value}))}
                value={weapon.character}/>

            <button className="btn btn-warning"
                onClick={() => {
                    history.back()}}>
                Cancel</button>
            <button className="btn btn-danger"
                onClick={() => deleteWeapon(weapon.id)}>
                Delete</button>
            <button className="btn btn-primary"
                onClick={() => updateWeapon(weapon.id, weapon)}>
                Save</button>
            <button className="btn btn-success"
                onClick={() => createWeapon(weapon)}>
                Create</button>
        </div>
    )
}

export default WeaponFormEditor