import characterService from "./character-service"
const {useState, useEffect} = React
const {Link, useParams, useHistory} = window.ReactRouterDOM;

const CharacterFormEditor = () => {
    const {id} = useParams()
    const [character, setCharacter] = useState({})
    useEffect(() => {
        if (id !== "new") {
            findCharacterById(id)
        }
    }, []);
    const findCharacterById = (id) =>
        characterService.findCharacterById(id)
            .then(character => setCharacter(character))
    const deleteCharacter = (id) =>
        characterService.deleteCharacter(id)
            .then(() => history.back())
    const createCharacter = (character) =>
        characterService.createCharacter(character)
            .then(() => history.back())
    const updateCharacter = (id, newCharacter) =>
        characterService.updateCharacter(id, newCharacter)
            .then(() => history.back())
    return (
        <div>
            <h2>Character Editor</h2>
            <label>Id</label>
            <input value={character.id}/><br/>
            <label>Name</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                        ({...character, name: e.target.value}))}
                value={character.name}/>
            <label>Level</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, level: e.target.value}))}
                value={character.level}/>
            <label>Rarity</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, rarity: e.target.value}))}
                value={character.rarity}/>
            <label>Attack</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, attack: e.target.value}))}
                value={character.attack}/>
            <label>Health</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, health: e.target.value}))}
                value={character.health}/>
            <label>Weapon Type</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, weaponType: e.target.value}))}
                value={character.weaponType}/>
            <label>Element</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, element: e.target.value}))}
                value={character.element}/>

            <Link onClick={() => window.location.replace(`index.html#/users/${character.user}`)}>
                User
            </Link>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                    ({...character, user: e.target.value}))}
                value={character.user}/>

            <Link onClick={() => window.location.replace(`weapons.html#/weapons/${character.weapon}`)}>
                Weapon
            </Link>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                    ({...character, weapon: e.target.value}))}
                value={character.weapon}/>

            <button className="btn btn-warning"
                onClick={() => {
                    history.back()}}>
                Cancel</button>
            <button className="btn btn-danger"
                onClick={() => deleteCharacter(character.id)}>
                Delete</button>
            <button className="btn btn-primary"
                onClick={() => updateCharacter(character.id, character)}>
                Save</button>
            <button className="btn btn-success"
                onClick={() => createCharacter(character)}>
                Create</button>
        </div>
    )
}

export default CharacterFormEditor