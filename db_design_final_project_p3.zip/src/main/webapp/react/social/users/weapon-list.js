import weaponService from "./weapon-service"
const {useState, useEffect} = React;
const {Link, useHistory} = window.ReactRouterDOM;

const WeaponList = () => {
    const history = useHistory()
    const [weapons, setWeapons] = useState([])
    useEffect(() => {
        findAllWeapons()
    }, [])
    const findAllWeapons = () =>
        weaponService.findAllWeapons()
            .then(weapons => setWeapons(weapons))
    return(
        <div>
            <h2>Weapon List</h2>
            <button className="btn btn-primary"
                onClick={() => history.push("/weapons/new")}>
                Add Weapon
            </button>
            <ul className="list-group">
            {
                weapons.map(weapon =>
                    <li className = "list-group-item"
                    key={weapon.id}>
                        <Link to={`/weapons/${weapon.id}`}>
                            {weapon.name}
                        </Link>
                    </li>)
            }
            </ul>
        </div>
    )
}

export default WeaponList;