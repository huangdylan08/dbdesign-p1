import WeaponList from "./users/weapon-list";
import WeaponFormEditor from "./users/weapon-form-editor";
const {HashRouter, Route} = window.ReactRouterDOM; 
const App = () => {
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/weapons", "/"]} exact={true}>
                    <WeaponList/>
                </Route>
                <Route path="/weapons/:id" exact={true}>
                    <WeaponFormEditor/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;
