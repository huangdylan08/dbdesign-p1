package com.example.springtemplate.repositories;

import com.example.springtemplate.models.Character;
import org.springframework.data.repository.CrudRepository;

public interface CharacterRepository
        extends CrudRepository<Character, Integer> {
}
