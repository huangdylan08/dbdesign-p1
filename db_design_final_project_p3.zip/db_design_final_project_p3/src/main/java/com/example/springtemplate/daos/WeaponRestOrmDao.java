package com.example.springtemplate.daos;

import com.example.springtemplate.models.Weapon;
import com.example.springtemplate.repositories.WeaponRestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class WeaponRestOrmDao {
    @Autowired
    WeaponRestRepository weaponRepository;

    @PostMapping("/api/weapons")
    public Weapon createWeapon(@RequestBody Weapon weapon) {
        return weaponRepository.save(weapon);
    }
    
    @GetMapping("/api/weapons")
    public List<Weapon> findAllWeapons() {
        return weaponRepository.findAllWeapons();
    }
    
    @GetMapping("/api/weapons/{weaponId}")
    public Weapon findWeaponById(
            @PathVariable("weaponId") Integer id) {
        return weaponRepository.findWeaponById(id);
    }
    
    @PutMapping("/api/weapons/{weaponId}")
    public Weapon updateWeapon(
            @PathVariable("weaponId") Integer id,
            @RequestBody Weapon weaponUpdates) {
        Weapon weapon = weaponRepository.findWeaponById(id);
        weapon.setName(weaponUpdates.getName());
        weapon.setWeaponType(weaponUpdates.getWeaponType());
        weapon.setLevel(weaponUpdates.getLevel());
        weapon.setRefinementLevel(weaponUpdates.getRefinementLevel());
        weapon.setRarity(weaponUpdates.getRarity());
        weapon.setBaseAttack(weaponUpdates.getBaseAttack());
        weapon.setAbilityName(weaponUpdates.getAbilityName());
        weapon.setAbilityDescription(weaponUpdates.getAbilityDescription());
        weapon.setCharacter(weaponUpdates.getCharacter());
        return weaponRepository.save(weapon);
    }
    
    @DeleteMapping("/api/weapons/{weaponId}")
    public void deleteWeapon(
            @PathVariable("weaponId") Integer id) {
        weaponRepository.deleteById(id);
    }
}