const {useState, useEffect } = React;
const {Link} = window.ReactRouterDOM;

const InlineWeaponEditor = ({weapon, deleteWeapon, updateWeapon}) => {
    const [weaponCopy, setWeaponCopy] = useState(weapon)
    const [editing, setEditing] = useState(false)
    return(
        <div>
            {
                editing &&
                <div className="row">
                    <div className="col">
                        <input
                            className="form-control"
                            value={weaponCopy.name}
                            onChange={(e)=>setWeaponCopy(weaponCopy => ({...weaponCopy, name: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={weaponCopy.weaponType}
                            onChange={(e)=>setWeaponCopy(weaponCopy => ({...weaponCopy, weaponType: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={weaponCopy.level}
                            onChange={(e)=>setWeaponCopy(weaponCopy => ({...weaponCopy, level: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={weaponCopy.refinementLevel}
                            onChange={(e)=>setWeaponCopy(weaponCopy => ({...weaponCopy, refinementLevel: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={weaponCopy.rarity}
                            onChange={(e)=>setWeaponCopy(weaponCopy => ({...weaponCopy, rarity: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={weaponCopy.baseAttack}
                            onChange={(e)=>setWeaponCopy(weaponCopy => ({...weaponCopy, baseAttack: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={weaponCopy.abilityName}
                            onChange={(e)=>setWeaponCopy(weaponCopy => ({...weaponCopy, abilityName: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={weaponCopy.abilityDescriptor}
                            onChange={(e)=>setWeaponCopy(weaponCopy => ({...weaponCopy, abilityDescriptor: e.target.value}))}/>
                    </div>


                    <div className="col-1">
                        <Link to={`/weapons/${weaponCopy.id}/character`}>
                            Characters
                        </Link>
                    </div>
                    <div className="col-2">
                        <i className="fas fa-2x fa-check float-right margin-left-10px"
                           onClick={() => {
                               setEditing(false)
                               updateWeapon(weaponCopy.id, weaponCopy)
                           }}></i>
                        <i className="fas fa-2x fa-undo float-right margin-left-10px"
                           onClick={() => setEditing(false)}></i>
                        <i className="fas fa-2x fa-trash float-right margin-left-10px"
                           onClick={() => deleteWeapon(weapon.id)}></i>
                    </div>
                </div>
            }
            {
                !editing &&
                <div className="row">
                    <div className="col">
                        <Link to={`/weapons/${weaponCopy.id}`}>
                            {weaponCopy.name}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/weapons/${weaponCopy.id}`}>
                            {weaponCopy.weaponType}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/weapons/${weaponCopy.id}`}>
                            {weaponCopy.level}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/weapons/${weaponCopy.id}`}>
                            {weaponCopy.refinementLevel}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/weapons/${weaponCopy.id}`}>
                            {weaponCopy.rarity}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/weapons/${weaponCopy.id}`}>
                            {weaponCopy.baseAttack}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/weapons/${weaponCopy.id}`}>
                            {weaponCopy.abilityName}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/weapons/${weaponCopy.id}`}>
                            {weaponCopy.abilityDescriptor}
                        </Link>
                    </div>

                    <div className="col-1">
                        <Link to={`/weapons/${weaponCopy.id}/character`}>
                            Blogs
                        </Link>
                    </div>
                    <div className="col-2">
                        <i className="fas fa-cog fa-2x float-right"
                           onClick={() => setEditing(true)}></i>
                    </div>
                </div>
            }
        </div>
    )
}

export default InlineWeaponEditor;