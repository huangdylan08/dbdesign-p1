import characterService from "./character-service"
const {useState, useEffect} = React
const {Link, useParams, useHistory} = window.ReactRouterDOM;

const CharacterFormEditor = () => {
    const {id} = useParams()
    const [character, setCharacter] = useState({})
    useEffect(() => {
        if (id !== "new") {
            findCharacterById(id)
        }
    }, []);
    const findCharacterById = (id) =>
        characterService.findCharacterById(id)
            .then(character => setCharacter(character))
    const deleteCharacter = (id) =>
        characterService.deleteCharacter(id)
            .then(() => history.back())
    const createCharacter = (character) =>
        characterService.createCharacter(character)
            .then(() => history.back())
    const updateCharacter = (id, newCharacter) =>
        characterService.updateCharacter(id, newCharacter)
            .then(() => history.back())
    var userId = null;
    var userName = null;
    if (character.user) {
        userId = character.user.id;
        userName = character.user.username;
    }
    var weaponId = null;
    var weaponName = null;
    if (character.weapon) {
        weaponId = character.weapon.id;
        weaponName = character.weapon.name;
    }
    return (
        <div>
            <h2>Character Editor</h2>
            <label>Id</label>
            <input value={character.id}/><br/>
            <label>Name</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                        ({...character, name: e.target.value}))}
                value={character.name}/><br/>
            <label>Level</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, level: e.target.value}))}
                value={character.level}/><br/>
            <label>Rarity</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, rarity: e.target.value}))}
                value={character.rarity}/><br/>
            <label>Attack</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, attack: e.target.value}))}
                value={character.attack}/><br/>
            <label>Health</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, health: e.target.value}))}
                value={character.health}/><br/>
            <label>Weapon Type</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, weaponType: e.target.value}))}
                value={character.weaponType}/><br/>
            <label>Element</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, element: e.target.value}))}
                value={character.element}/><br/>

            <label>User</label>
            <Link onClick={() => window.location.replace(`index.html#/users/${userId}`)}>
                {userName}
            </Link><br/>

            <label>Weapon</label>
            <Link onClick={() => window.location.replace(`weapons.html#/weapons/${weaponId}`)}>
                {weaponName}
            </Link><br/>

            <button className="btn btn-warning"
                onClick={() => {
                    history.back()}}>
                Cancel</button>
            <button className="btn btn-danger"
                onClick={() => deleteCharacter(character.id)}>
                Delete</button>
            <button className="btn btn-primary"
                onClick={() => updateCharacter(character.id, character)}>
                Save</button>
            <button className="btn btn-success"
                onClick={() => createCharacter(character)}>
                Create</button>
        </div>
    )
}

export default CharacterFormEditor