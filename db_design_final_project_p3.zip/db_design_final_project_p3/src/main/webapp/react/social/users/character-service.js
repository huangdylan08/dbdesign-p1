// TODO: declare URL where server listens for HTTP requests
const CHARACTERS_URL = "http://localhost:8080/api/characters"

// TODO: retrieve all users from the server
export const findAllCharacters = () =>
    fetch(CHARACTERS_URL)
    .then(response => response.json())

// TODO: retrieve a single user by their ID
export const findCharacterById = (id) =>
    fetch(`${CHARACTERS_URL}/${id}`)
        .then(response => response.json())

// TODO: delete a user by their ID
export const deleteCharacter = (id) =>
    fetch(`${CHARACTERS_URL}/${id}`, {
        method: "DELETE"
    })

// TODO: create a new user
export const createCharacter = (character) =>
    fetch(CHARACTERS_URL, {
        method: 'POST',
        body: JSON.stringify(character),
        headers: {'content-type':'application/json'}
    })

// TODO: update a user by their ID
export const updateCharacter = (id, character) =>
    fetch(`${CHARACTERS_URL}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(character),
        headers: {'content-type':'application/json'}
    })
    .then(response => response.json())

// TODO: export all functions as the API to this service
export default {
    findAllCharacters,
    findCharacterById,
    deleteCharacter,
    createCharacter,
    updateCharacter
}
