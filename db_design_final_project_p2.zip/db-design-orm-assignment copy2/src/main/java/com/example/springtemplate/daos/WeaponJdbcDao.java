package com.example.springtemplate.daos;

import com.example.springtemplate.models.Weapon;
import com.example.springtemplate.models.WeaponType;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class WeaponJdbcDao {
    static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String HOST = "localhost:3306";
    static final String SCHEMA = "YOUR_SCHEMA";
    static final String CONFIG = "serverTimezone=UTC";
    static final String URL =
            "jdbc:mysql://"+HOST+"/"+SCHEMA+"?"+CONFIG;
    static final String USERNAME = "YOUR_USERNAME";
    static final String PASSWORD = "YOUR_PASSWORD";
    
    static Connection connection = null;
    static PreparedStatement statement = null;
    String CREATE_WEAPON = "INSERT INTO weapons VALUES (null, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    String FIND_ALL_WEAPONS = "SELECT * FROM weapons";
    String FIND_WEAPON_BY_ID = "SELECT * FROM weapons WHERE id=?";
    String DELETE_WEAPON = "DELETE FROM weapons WHERE id=?";
    String UPDATE_WEAPON = "UPDATE weapons SET name=?, weapon_type=?, level=?, refinement_level=?, rarity=?, base_attack=?, ability_name=?, ability_description=?, character_id=? WHERE id=?";
    
    private Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName(DRIVER);
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
    
    private void closeConnection(Connection connection) throws SQLException {
        connection.close();
    }
    
    public Weapon findWeaponById(Integer id) throws SQLException, ClassNotFoundException {
        CharacterJdbcDao characterJdbcDao = new CharacterJdbcDao();
        Weapon weapon = null;
        connection = getConnection();

        statement = connection.prepareStatement(FIND_WEAPON_BY_ID);
        statement.setInt(1, id);
        ResultSet resultSet = statement.executeQuery();
        if(resultSet.next()) {
            weapon = new Weapon(
                    resultSet.getString("name"),
                    resultSet.getString("weapon_type"),
                    resultSet.getInt("level"),
                    resultSet.getInt("refinement_level"),
                    resultSet.getInt("rarity"),
                    resultSet.getInt("base_attack"),
                    resultSet.getString("ability_name"),
                    resultSet.getString("ability_description"),
                    characterJdbcDao.findCharacterById(resultSet.getInt("character_id"))
            );
        }

        closeConnection(connection);
        return weapon;
    }
    
    public Integer deleteWeapon(Integer weaponId) throws SQLException, ClassNotFoundException {
        Integer rowsDeleted = 0;
        connection = getConnection();

        statement = connection.prepareStatement(DELETE_WEAPON);
        statement.setInt(1, weaponId);
        rowsDeleted = statement.executeUpdate();

        closeConnection(connection);
        return rowsDeleted;
    }
    
    public Integer updateWeapon(Integer weaponId, Weapon newWeapon) throws SQLException, ClassNotFoundException {
        Integer rowsUpdated = 0;
        connection = getConnection();

        statement = connection.prepareStatement(UPDATE_WEAPON);
        statement.setString(1, newWeapon.getName());
        statement.setString(2, newWeapon.getWeaponType().toString());
        statement.setInt(3, newWeapon.getLevel());
        statement.setInt(4, newWeapon.getRefinementLevel());
        statement.setInt(5, newWeapon.getRarity());
        statement.setInt(6, newWeapon.getBaseAttack());
        statement.setString(7, newWeapon.getAbilityName());
        statement.setString(8, newWeapon.getAbilityDescription());
        statement.setInt(9, newWeapon.getCharacter().getId());
        statement.setInt(10, weaponId);
        rowsUpdated = statement.executeUpdate();

        closeConnection(connection);
        return rowsUpdated;
    }
    
    public List<Weapon> findAllWeapons() throws ClassNotFoundException, SQLException {
        CharacterJdbcDao characterJdbcDao = new CharacterJdbcDao();
        List<Weapon> weapons = new ArrayList<Weapon>();
        connection = getConnection();

        statement = connection.prepareStatement(FIND_ALL_WEAPONS);
        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            Weapon weapon = new Weapon(
                    resultSet.getString("name"),
                    resultSet.getString("weapon_type"),
                    resultSet.getInt("level"),
                    resultSet.getInt("refinement_level"),
                    resultSet.getInt("rarity"),
                    resultSet.getInt("base_attack"),
                    resultSet.getString("ability_name"),
                    resultSet.getString("ability_description"),
                    characterJdbcDao.findCharacterById(resultSet.getInt("character_id"))
            );
            weapons.add(weapon);
        }

        closeConnection(connection);
        return weapons;
    }
    public Integer createWeapon(Weapon weapon)
            throws ClassNotFoundException, SQLException {
        Integer rowsUpdated = 0;
        connection = getConnection();

        statement = connection.prepareStatement(CREATE_WEAPON);
        statement.setString(1, weapon.getName());
        statement.setString(2, weapon.getWeaponType().toString());
        statement.setInt(3, weapon.getLevel());
        statement.setInt(4, weapon.getRefinementLevel());
        statement.setInt(5, weapon.getRarity());
        statement.setInt(6, weapon.getBaseAttack());
        statement.setString(7, weapon.getAbilityName());
        statement.setString(8, weapon.getAbilityDescription());
        statement.setInt(9, weapon.getCharacter().getId());
        rowsUpdated = statement.executeUpdate();

        closeConnection(connection);
        return rowsUpdated;
    }
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        WeaponJdbcDao dao = new WeaponJdbcDao();
    }
}
