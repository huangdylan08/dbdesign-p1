const {useState, useEffect } = React;
const {Link} = window.ReactRouterDOM;

const InlineCharacterEditor = ({character, deleteCharacter, updateCharacter}) => {
    const [characterCopy, setCharacterCopy] = useState(character)
    const [editing, setEditing] = useState(false)
    return(
        <div>
            {
                editing &&
                <div className="row">
                    <div className="col">
                        <input
                            className="form-control"
                            value={characterCopy.name}
                            onChange={(e)=>setCharacterCopy(characterCopy => ({...characterCopy, name: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={characterCopy.level}
                            onChange={(e)=>setCharacterCopy(characterCopy => ({...characterCopy, level: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={characterCopy.rarity}
                            onChange={(e)=>setCharacterCopy(characterCopy => ({...characterCopy, rarity: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={characterCopy.attack}
                            onChange={(e)=>setCharacterCopy(characterCopy => ({...characterCopy, attack: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={characterCopy.health}
                            onChange={(e)=>setCharacterCopy(characterCopy => ({...characterCopy, health: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={characterCopy.weaponType}
                            onChange={(e)=>setCharacterCopy(characterCopy => ({...characterCopy, weaponType: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={characterCopy.element}
                            onChange={(e)=>setCharacterCopy(characterCopy => ({...characterCopy, element: e.target.value}))}/>
                    </div>

                    <div className="col-1">
                        <Link to={`/characters/${characterCopy.id}/weapon`}>
                            Weapon
                        </Link>
                    </div>
                    <div className="col-2">
                        <i className="fas fa-2x fa-check float-right margin-left-10px"
                           onClick={() => {
                               setEditing(false)
                               updateCharacter(characterCopy.id, characterCopy)
                           }}></i>
                        <i className="fas fa-2x fa-undo float-right margin-left-10px"
                           onClick={() => setEditing(false)}></i>
                        <i className="fas fa-2x fa-trash float-right margin-left-10px"
                           onClick={() => deleteCharacter(character.id)}></i>
                    </div>
                </div>
            }
            {
                !editing &&
                <div className="row">
                    <div className="col">
                        <Link to={`/characters/${characterCopy.id}`}>
                            {characterCopy.name}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/characters/${characterCopy.id}`}>
                            {characterCopy.level}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/characters/${characterCopy.id}`}>
                            {characterCopy.rarity}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/characters/${characterCopy.id}`}>
                            {characterCopy.attack}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/characters/${characterCopy.id}`}>
                            {characterCopy.health}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/characters/${characterCopy.id}`}>
                            {characterCopy.weaponType}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/characters/${characterCopy.id}`}>
                            {characterCopy.element}
                        </Link>
                    </div>

                    <div className="col-1">
                        <Link to={`/characters/${characterCopy.id}/weapons`}>
                            Blogs
                        </Link>
                    </div>
                    <div className="col-2">
                        <i className="fas fa-cog fa-2x float-right"
                           onClick={() => setEditing(true)}></i>
                    </div>
                </div>
            }
        </div>
    )
}

export default InlineCharacterEditor;