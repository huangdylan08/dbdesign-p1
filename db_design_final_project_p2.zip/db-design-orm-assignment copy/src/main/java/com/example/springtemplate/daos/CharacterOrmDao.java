package com.example.springtemplate.daos;

import com.example.springtemplate.models.Character;
import com.example.springtemplate.repositories.CharacterRestRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class CharacterOrmDao {
    @Autowired
    CharacterRestRepository characterRepository;
    public Character createCharacter() { return null; }
    public List<Character> findAllCharacters() { return null; }
    public Character findCharacterById(Integer id) { return null; }
    public Integer deleteCharacter(Integer id) { return null; }
    public Integer updateCharacter() { return null; }
}
