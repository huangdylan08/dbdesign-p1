package com.example.springtemplate.repositories;

import com.example.springtemplate.models.Character;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CharacterRestRepository
        extends CrudRepository<Character, Integer> {
    @Query(value = "SELECT * FROM characters",
            nativeQuery = true)
    public List<Character> findAllCharacters();
    @Query(value = "SELECT * FROM characters WHERE id=:characterId",
            nativeQuery = true)
    public Character findCharacterById(@Param("characterId") Integer id);
}
