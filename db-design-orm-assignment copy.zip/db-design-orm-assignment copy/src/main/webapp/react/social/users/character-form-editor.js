import characterService from "./user-service"
const {useState, useEffect} = React
const {useParams, useHistory} = window.ReactRouterDOM;
const CharacterFormEditor = () => {
    const {id} = useParams()
    const [character, setCharacter] = useState({})
    useEffect(() => {
        if (id !== "new") {
            findCharacterById(id)
        }
    }, []);
    const findCharacterById = (id) =>
        characterService.findCharacterById(id)
            .then(user => setCharacter(character))
    const deleteCharacter = (id) =>
        characterService.deleteCharacter(id)
            .then(() => history.back())
    const createCharacter = (character) =>
        characterService.createUser(character)
            .then(() => history.back())
    const updateCharacter = (id, newCharacter) =>
        characterService.updateCharacter(id, newCharacter)
            .then(() => history.back())
    return (
        <div>
            <h2>Character Editor</h2>
            <label>Id</label>
            <input value={character.id}/><br/>
            <label>Name</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                        ({...character, name: e.target.value}))}
                value={character.name}/>
            <label>Level</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, level: e.target.value}))}
                value={character.level}/>
            <label>Rarity</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, rarity: e.target.value}))}
                value={character.rarity}/>
            <label>Attack</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, attack: e.target.value}))}
                value={character.attack}/>
            <label>Health</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, health: e.target.value}))}
                value={character.health}/>
            <label>Weapon Type</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, weaponType: e.target.value}))}
                value={character.weaponType}/>
            <label>Element</label>
            <input
                onChange={(e) =>
                    setCharacter(character =>
                                     ({...character, element: e.target.value}))}
                value={character.element}/>



            <button className="btn btn-warning"
                onClick={() => {
                    history.back()}}>
                Cancel</button>
            <button className="btn btn-danger"
                onClick={() => deleteUser(user.id)}>
                Delete</button>
            <button className="btn btn-primary"
                onClick={() => updateUser(user.id, user)}>
                Save</button>
            <button className="btn btn-success"
                onClick={() => createUser(user)}>
                Create</button>
        </div>
    )
}

export default UserFormEditor