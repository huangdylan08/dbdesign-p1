import characterService from "./character-service"
const {useState, useEffect} = React;
const {Link, useHistory} = window.ReactRouterDOM;

const CharacterList = () => {
    const history = useHistory()
    const [characters, setCharacters] = useState([])
    useEffect(() => {
        findAllCharacters()
    }, [])
    const findAllCharacters = () =>
        characterService.findAllCharacters()
            .then(characters => setCharacters(characters))
    return(
        <div>
            <h2>User List</h2>
            <button className="btn btn-primary"
                onClick={() => history.push("/characters/new")}>
                Add Character
            </button>
            <ul className="list-group">
            {
                characters.map(character =>
                    <li className = "list-group-item"
                    key={character.id}>
                        <Link to={`/characters/${character.id}`}>
                            {character.name}
                        </Link>
                    </li>)
            }
            </ul>
        </div>
    )
}

export default CharacterList;