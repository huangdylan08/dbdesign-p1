package com.example.springtemplate.models;

public enum WeaponType {
    Bow ("Bow"),
    Catalyst ("Catalyst"),
    Claymore ("Claymore"),
    Polearm ("Polearm"),
    Sword ("Sword");

    private final String weaponType;

    WeaponType(String weaponType) {
        this.weaponType = weaponType;
    }
}
