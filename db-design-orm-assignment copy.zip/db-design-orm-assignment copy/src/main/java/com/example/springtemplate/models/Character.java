package com.example.springtemplate.models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name="characters")
public class Character {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private Integer level;
    private Integer rarity;
    private Integer attack;
    private Integer health;
    private WeaponType weaponType;
    private Element element;

    @ManyToOne
    @JsonIgnore
    private User user;

    @OneToOne
    private Weapon weapon;

    public Character() {

    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Integer getLevel() { return level; }
    public void setLevel(Integer level) { this.level = level; }
    public Integer getRarity() { return rarity; }
    public void setRarity(Integer rarity) { this.rarity = rarity; }
    public Integer getAttack() { return attack; }
    public void setAttack(Integer attack) { this.attack = attack; }
    public Integer getHealth() { return health; }
    public void setHealth(Integer health) { this.health = health; }
    public WeaponType getWeaponType() { return weaponType; }
    public void setWeaponType(WeaponType weaponType) { this.weaponType = weaponType; }
    public Element getElement() { return element; }
    public void setElement(Element element) { this.element = element; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Character(String name, Integer level, Integer rarity, Integer attack, Integer health, WeaponType weaponType, Element element, User user) {
        this.name = name;
        this.level = level;
        this.rarity = rarity;
        this.attack = attack;
        this.health = health;
        this.weaponType = weaponType;
        this.element = element;
        this.user = user;
    }
}
