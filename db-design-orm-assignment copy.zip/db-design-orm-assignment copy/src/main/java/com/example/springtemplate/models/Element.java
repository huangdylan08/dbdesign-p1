package com.example.springtemplate.models;

public enum Element {
    Anemo,
    Cryo,
    Electro,
    Geo,
    Hydro,
    Pyro;
}
