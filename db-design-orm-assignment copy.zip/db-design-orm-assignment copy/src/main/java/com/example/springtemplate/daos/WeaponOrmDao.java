package com.example.springtemplate.daos;

import com.example.springtemplate.models.Weapon;
import com.example.springtemplate.repositories.WeaponRestRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class WeaponOrmDao {
    @Autowired
    WeaponRestRepository weaponRepository;
    public Weapon createWeapon() { return null; }
    public List<Weapon> findAllWeapons() { return null; }
    public Weapon findWeaponById(Integer id) { return null; }
    public Integer deleteWeapon(Integer id) { return null; }
    public Integer updateWeapon() { return null; }
}
